const formInputs = document.querySelectorAll('input');

// The background color of each form input must change to yellow when it is selected.
formInputs.forEach(input => {
  input.addEventListener('focus', () => {

    input.style.backgroundColor = 'yellow';
  });

// Background color of each form input must change to white when user leaves input field.
  input.addEventListener('blur', () => {

    input.style.backgroundColor = 'white';
  });
});

// Background color of each button must change to light blue when the mouse pointer is moving onto a button.
const buttons = document.querySelectorAll('button, input[type="submit"]');

buttons.forEach(button => {
  button.addEventListener('mouseover', () => {
    button.style.backgroundColor = 'lightblue';
  });

  button.addEventListener('mouseout', () => {
    button.style.backgroundColor = '';
  });
});
